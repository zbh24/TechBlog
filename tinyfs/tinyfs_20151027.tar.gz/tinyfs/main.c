#include<stdio.h>
#include "types.h"
#include "defs.h"
#include "param.h"
#include "stat.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "fs.h"
#include "buf.h"
#include "file.h"
#include "fcntl.h"
int main() 
{

	int fd;
	char buf[512];

	binit();
	initlog(1);
	iinit(1);
        fileinit();
	initproc();
	memset(buf,0,512);

	//Read a file
	fd = sys_open("/test_file2",0);
	sys_read(fd,buf,512);
	printf("The data is %s\n",buf);
	sys_close(fd);

	//First write,then read
	fd = sys_open("/JangGang",O_CREATE);
	sys_close(fd);

	fd = sys_open("/zbhXXYYY",O_WRONLY);
	memset(buf,'\0',512);
	memset(buf,'a',100);
	sys_write(fd,buf,512);
	sys_close(fd);

	fd = sys_open("/zbhXXYYY",O_RDONLY);
	memset(buf,0,512);
	sys_read(fd,buf,512);
	printf("The new write is %s\n",buf);
	sys_close(fd);

}

